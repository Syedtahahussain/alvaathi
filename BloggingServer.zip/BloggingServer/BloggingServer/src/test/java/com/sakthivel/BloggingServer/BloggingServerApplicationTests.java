package com.sakthivel.BloggingServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloggingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
